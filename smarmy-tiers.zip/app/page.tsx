import { Leaderboard } from "@/components/leaderboard"
import { SiteHeader } from "@/components/site-header"
import { getAllRanking, getGamemodeRanking } from "@/lib/data"

export const dynamic = "force-dynamic"

export default async function HomePage() {
  const [all, friendship] = await Promise.all([
    getAllRanking(),
    getGamemodeRanking("friendship"),
  ])

  return (
    <main className="min-h-dvh">
      <SiteHeader />
      <div className="mx-auto max-w-2xl px-4 py-6">
        <Leaderboard all={all} friendship={friendship} />
      </div>
    </main>
  )
}
