"use server"

import { revalidatePath } from "next/cache"
import { query } from "@/lib/db"
import { isAdmin, signInAdmin, signOutAdmin } from "@/lib/admin"
import { GAMEMODES } from "@/lib/tiers"

async function requireAdmin() {
  if (!(await isAdmin())) throw new Error("Unauthorized")
}

export async function loginAction(_prev: unknown, formData: FormData) {
  const code = String(formData.get("code") ?? "")
  const ok = await signInAdmin(code)
  if (!ok) return { error: "Invalid access code." }
  revalidatePath("/admin")
  return { error: null }
}

export async function logoutAction() {
  await signOutAdmin()
  revalidatePath("/admin")
}

export async function createPlayer(formData: FormData) {
  await requireAdmin()
  const username = String(formData.get("username") ?? "").trim()
  const region = String(formData.get("region") ?? "").trim() || null
  if (!username) return
  await query(`INSERT INTO players (username, region) VALUES ($1, $2)`, [username, region])
  revalidatePath("/admin")
  revalidatePath("/")
}

export async function deletePlayer(formData: FormData) {
  await requireAdmin()
  const id = Number(formData.get("id"))
  if (!id) return
  await query(`DELETE FROM player_tiers WHERE player_id = $1`, [id])
  await query(`DELETE FROM players WHERE id = $1`, [id])
  revalidatePath("/admin")
  revalidatePath("/")
}

export async function setTier(formData: FormData) {
  await requireAdmin()
  const playerId = Number(formData.get("playerId"))
  const gamemode = String(formData.get("gamemode") ?? "")
  const tier = Number(formData.get("tier"))
  const tierType = String(formData.get("tierType") ?? "")

  const validGamemode = GAMEMODES.some((g) => g.id === gamemode)
  if (!playerId || !validGamemode || tier < 1 || tier > 5 || !["HT", "LT"].includes(tierType)) {
    return
  }

  await query(
    `INSERT INTO player_tiers (player_id, gamemode, tier, tier_type)
     VALUES ($1, $2, $3, $4)
     ON CONFLICT (player_id, gamemode)
     DO UPDATE SET tier = EXCLUDED.tier, tier_type = EXCLUDED.tier_type`,
    [playerId, gamemode, tier, tierType],
  )
  revalidatePath("/admin")
  revalidatePath("/")
}

export async function removeTier(formData: FormData) {
  await requireAdmin()
  const playerId = Number(formData.get("playerId"))
  const gamemode = String(formData.get("gamemode") ?? "")
  if (!playerId || !gamemode) return
  await query(`DELETE FROM player_tiers WHERE player_id = $1 AND gamemode = $2`, [playerId, gamemode])
  revalidatePath("/admin")
  revalidatePath("/")
}
