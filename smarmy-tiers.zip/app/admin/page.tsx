import { AdminLogin } from "@/components/admin-login"
import { AdminPanel } from "@/components/admin-panel"
import { isAdmin } from "@/lib/admin"
import { getPlayers } from "@/lib/data"

export const dynamic = "force-dynamic"

export const metadata = {
  robots: { index: false, follow: false },
}

export default async function AdminPage() {
  if (!(await isAdmin())) {
    return <AdminLogin />
  }

  const players = await getPlayers()
  const sorted = [...players].sort((a, b) => a.username.localeCompare(b.username))

  return <AdminPanel players={sorted} />
}
