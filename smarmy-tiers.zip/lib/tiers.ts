// Central tier/points configuration for Smarmy Tiers.
// LT/HT system just like mctiers.

export type TierType = "HT" | "LT"

export const GAMEMODES = [
  { id: "friendship", label: "Friendship" },
] as const

export type GamemodeId = (typeof GAMEMODES)[number]["id"]

// Points table (matches the reference):
// TIER 1  HT 60 / LT 45
// TIER 2  HT 30 / LT 20
// TIER 3  HT 10 / LT 6
// TIER 4  HT 4  / LT 3
// TIER 5  HT 2  / LT 1
export const POINTS: Record<number, { HT: number; LT: number }> = {
  1: { HT: 60, LT: 45 },
  2: { HT: 30, LT: 20 },
  3: { HT: 10, LT: 6 },
  4: { HT: 4, LT: 3 },
  5: { HT: 2, LT: 1 },
}

export function pointsFor(tier: number, type: TierType): number {
  const row = POINTS[tier]
  if (!row) return 0
  return row[type] ?? 0
}

// Formats a tier badge label, e.g. "HT1", "LT3".
export function tierLabel(tier: number, type: TierType): string {
  return `${type}${tier}`
}

// Title thresholds based on combined points (used in the "All" section).
export type Title = { name: string; className: string }

export function titleFor(points: number): Title {
  if (points >= 400) return { name: "SMARMY GRANDMASTER", className: "text-amber-400" }
  if (points >= 250) return { name: "SMARMY MASTER", className: "text-orange-400" }
  if (points >= 100) return { name: "SMARMY ACE", className: "text-rose-400" }
  if (points >= 50) return { name: "SMARMY SPECIALIST", className: "text-red-400" }
  if (points >= 10) return { name: "SMARMY CADET", className: "text-red-300" }
  if (points > 0) return { name: "SMARMY ROOKIE", className: "text-muted-foreground" }
  return { name: "UNRANKED", className: "text-muted-foreground" }
}

// Color styling per tier for the little tier badges.
export function tierBadgeClasses(tier: number, type: TierType): string {
  // HT is "high" (hot/red-orange), LT is "low" (cooler/green) — mirrors mctiers.
  if (type === "HT") {
    switch (tier) {
      case 1:
        return "bg-amber-500/15 text-amber-400 border-amber-500/30"
      case 2:
        return "bg-orange-500/15 text-orange-400 border-orange-500/30"
      case 3:
        return "bg-red-500/15 text-red-400 border-red-500/30"
      default:
        return "bg-red-900/30 text-red-300 border-red-800/40"
    }
  }
  // LT
  switch (tier) {
    case 1:
      return "bg-emerald-500/10 text-emerald-400 border-emerald-500/25"
    case 2:
      return "bg-teal-500/10 text-teal-300 border-teal-500/25"
    default:
      return "bg-slate-500/10 text-slate-300 border-slate-500/25"
  }
}

// Rank number coloring (#1 gold, #2 silver, #3 bronze).
export function rankClass(rank: number): string {
  if (rank === 1) return "text-amber-400"
  if (rank === 2) return "text-slate-300"
  if (rank === 3) return "text-orange-400"
  return "text-muted-foreground"
}

// Skin avatar (head) and full body via mc-heads (no API key required).
export function skinHead(username: string): string {
  return `https://mc-heads.net/avatar/${encodeURIComponent(username)}/96`
}

export function skinBody(username: string): string {
  return `https://mc-heads.net/body/${encodeURIComponent(username)}/128`
}
