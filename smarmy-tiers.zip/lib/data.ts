import "server-only"
import { query } from "./db"
import { pointsFor, type TierType } from "./tiers"

export type PlayerTier = {
  gamemode: string
  tier: number
  tierType: TierType
  points: number
}

export type Player = {
  id: number
  username: string
  region: string | null
  tiers: PlayerTier[]
  totalPoints: number
}

type RawRow = {
  id: number
  username: string
  region: string | null
  gamemode: string | null
  tier: number | null
  tier_type: string | null
}

// Returns every player with their per-gamemode tiers and combined total points.
export async function getPlayers(): Promise<Player[]> {
  const rows = await query<RawRow>(
    `SELECT p.id, p.username, p.region,
            t.gamemode, t.tier, t.tier_type
     FROM players p
     LEFT JOIN player_tiers t ON t.player_id = p.id
     ORDER BY p.username ASC`,
  )

  const map = new Map<number, Player>()
  for (const r of rows) {
    let player = map.get(r.id)
    if (!player) {
      player = {
        id: r.id,
        username: r.username,
        region: r.region,
        tiers: [],
        totalPoints: 0,
      }
      map.set(r.id, player)
    }
    if (r.gamemode && r.tier && r.tier_type) {
      const type = r.tier_type as TierType
      const pts = pointsFor(r.tier, type)
      player.tiers.push({
        gamemode: r.gamemode,
        tier: r.tier,
        tierType: type,
        points: pts,
      })
      player.totalPoints += pts
    }
  }

  return Array.from(map.values())
}

// Combined "All" ranking: sum of points across every gamemode, ranked numerically.
export async function getAllRanking(): Promise<Player[]> {
  const players = await getPlayers()
  return players
    .filter((p) => p.totalPoints > 0)
    .sort((a, b) => b.totalPoints - a.totalPoints || a.username.localeCompare(b.username))
}

// Ranking for a single gamemode, ranked by that gamemode's points.
export async function getGamemodeRanking(gamemode: string): Promise<Player[]> {
  const players = await getPlayers()
  return players
    .map((p) => ({
      player: p,
      gm: p.tiers.find((t) => t.gamemode === gamemode),
    }))
    .filter((x) => x.gm)
    .sort((a, b) => (b.gm!.points - a.gm!.points) || a.player.username.localeCompare(b.player.username))
    .map((x) => x.player)
}
