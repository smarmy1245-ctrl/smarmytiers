"use client"

import { useActionState } from "react"
import { Lock } from "lucide-react"
import { loginAction } from "@/app/actions/admin"

export function AdminLogin() {
  const [state, formAction, pending] = useActionState(loginAction, { error: null as string | null })

  return (
    <div className="flex min-h-dvh items-center justify-center px-4">
      <form
        action={formAction}
        className="w-full max-w-sm rounded-2xl border border-border bg-card p-6"
      >
        <div className="mb-4 flex items-center gap-2">
          <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/15 text-primary">
            <Lock className="h-5 w-5" />
          </span>
          <div>
            <h1 className="text-lg font-bold font-display text-foreground">Admin Access</h1>
            <p className="text-xs text-muted-foreground">Enter the access code to continue.</p>
          </div>
        </div>

        <input
          type="password"
          name="code"
          autoComplete="off"
          placeholder="Access code"
          className="min-h-11 w-full rounded-lg border border-border bg-background px-3 text-base text-foreground outline-none focus:border-primary"
          required
        />

        {state?.error && <p className="mt-2 text-sm text-primary">{state.error}</p>}

        <button
          type="submit"
          disabled={pending}
          className="mt-4 min-h-11 w-full rounded-lg bg-primary px-4 font-bold text-primary-foreground transition-opacity disabled:opacity-60"
        >
          {pending ? "Checking..." : "Unlock"}
        </button>
      </form>
    </div>
  )
}
