import { Heart } from "lucide-react"
import type { Player } from "@/lib/data"
import { GAMEMODES, rankClass, skinHead, tierBadgeClasses, tierLabel, titleFor } from "@/lib/tiers"
import { cn } from "@/lib/utils"

function gamemodeLabel(id: string) {
  return GAMEMODES.find((g) => g.id === id)?.label ?? id
}

function TierChip({
  tier,
  type,
  gamemode,
  showGamemode,
}: {
  tier: number
  type: "HT" | "LT"
  gamemode: string
  showGamemode?: boolean
}) {
  return (
    <div
      className={cn(
        "flex items-center gap-1.5 rounded-md border px-2 py-1 text-xs font-semibold",
        tierBadgeClasses(tier, type),
      )}
    >
      <Heart className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
      <span className="font-mono tabular-nums">{tierLabel(tier, type)}</span>
      {showGamemode && <span className="font-medium opacity-80">{gamemodeLabel(gamemode)}</span>}
    </div>
  )
}

export function PlayerRow({
  player,
  rank,
  mode,
}: {
  player: Player
  rank: number
  mode: "all" | string
}) {
  const isAll = mode === "all"
  const title = titleFor(player.totalPoints)

  // Which tiers to show, and which points to display.
  const shownTiers = isAll ? player.tiers : player.tiers.filter((t) => t.gamemode === mode)
  const displayPoints = isAll
    ? player.totalPoints
    : shownTiers.reduce((sum, t) => sum + t.points, 0)

  const top3 = rank <= 3

  return (
    <li
      className={cn(
        "rounded-xl border bg-card p-4 transition-colors",
        top3 ? "border-primary/40 shadow-[0_0_0_1px_rgba(225,29,46,0.15)]" : "border-border",
      )}
    >
      <div className="flex items-center gap-3">
        <span className={cn("w-10 shrink-0 text-2xl font-extrabold font-display tabular-nums", rankClass(rank))}>
          {`#${rank}`}
        </span>

        <img
          src={skinHead(player.username) || "/placeholder.svg"}
          alt={`${player.username} Minecraft skin`}
          width={48}
          height={48}
          className="h-12 w-12 shrink-0 rounded-md border border-border bg-secondary"
          crossOrigin="anonymous"
        />

        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <p className="truncate text-lg font-bold font-display leading-tight text-foreground">
              {player.username}
            </p>
            {player.region && (
              <span className="shrink-0 rounded border border-border bg-secondary px-1.5 py-0.5 text-[10px] font-bold text-muted-foreground">
                {player.region}
              </span>
            )}
          </div>
          <p className={cn("text-xs font-bold tracking-wide", title.className)}>
            {isAll ? title.name : gamemodeLabel(mode).toUpperCase()}
          </p>
          <p className="mt-0.5 text-sm font-semibold text-muted-foreground">
            {displayPoints} <span className="text-xs font-medium">pts</span>
          </p>
        </div>
      </div>

      {shownTiers.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-2 border-t border-border pt-3">
          {shownTiers.map((t) => (
            <TierChip
              key={t.gamemode}
              tier={t.tier}
              type={t.tierType}
              gamemode={t.gamemode}
              showGamemode={isAll}
            />
          ))}
        </div>
      )}
    </li>
  )
}
