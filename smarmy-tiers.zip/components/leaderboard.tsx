"use client"

import { useState } from "react"
import { Heart, Star } from "lucide-react"
import type { Player } from "@/lib/data"
import { PlayerRow } from "./player-row"
import { cn } from "@/lib/utils"

type Tab = { id: string; label: string; icon: React.ReactNode }

const TABS: Tab[] = [
  { id: "all", label: "All", icon: <Star className="h-4 w-4" aria-hidden="true" /> },
  { id: "friendship", label: "Friendship", icon: <Heart className="h-4 w-4" aria-hidden="true" /> },
]

export function Leaderboard({
  all,
  friendship,
}: {
  all: Player[]
  friendship: Player[]
}) {
  const [tab, setTab] = useState<string>("all")
  const players = tab === "all" ? all : friendship

  return (
    <section aria-label="Tier rankings">
      <div className="mb-5 flex gap-2 overflow-x-auto pb-1" role="tablist" aria-label="Gamemodes">
        {TABS.map((t) => {
          const active = tab === t.id
          return (
            <button
              key={t.id}
              role="tab"
              aria-selected={active}
              onClick={() => setTab(t.id)}
              className={cn(
                "flex min-h-11 shrink-0 items-center gap-2 rounded-lg border px-4 text-sm font-bold transition-colors",
                active
                  ? "border-primary bg-primary/15 text-primary"
                  : "border-border bg-card text-muted-foreground hover:text-foreground",
              )}
            >
              {t.icon}
              {t.label}
            </button>
          )
        })}
      </div>

      {players.length === 0 ? (
        <div className="rounded-xl border border-border bg-card p-8 text-center text-muted-foreground">
          No ranked players yet.
        </div>
      ) : (
        <ol className="flex flex-col gap-3">
          {players.map((p, i) => (
            <PlayerRow key={p.id} player={p} rank={i + 1} mode={tab} />
          ))}
        </ol>
      )}
    </section>
  )
}
