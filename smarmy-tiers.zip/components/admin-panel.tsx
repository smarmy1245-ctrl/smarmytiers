import { LogOut, Plus, Trash2 } from "lucide-react"
import type { Player } from "@/lib/data"
import { GAMEMODES, skinHead, tierLabel } from "@/lib/tiers"
import { createPlayer, deletePlayer, logoutAction, removeTier, setTier } from "@/app/actions/admin"

function TierEditor({ player }: { player: Player }) {
  return (
    <div className="mt-3 flex flex-col gap-2 border-t border-border pt-3">
      {GAMEMODES.map((gm) => {
        const current = player.tiers.find((t) => t.gamemode === gm.id)
        return (
          <div key={gm.id} className="flex flex-wrap items-center gap-2">
            <span className="w-24 text-sm font-semibold text-foreground">{gm.label}</span>

            <form action={setTier} className="flex flex-wrap items-center gap-2">
              <input type="hidden" name="playerId" value={player.id} />
              <input type="hidden" name="gamemode" value={gm.id} />
              <select
                name="tierType"
                defaultValue={current?.tierType ?? "HT"}
                className="min-h-9 rounded-md border border-border bg-background px-2 text-sm text-foreground"
                aria-label={`${gm.label} tier type`}
              >
                <option value="HT">HT</option>
                <option value="LT">LT</option>
              </select>
              <select
                name="tier"
                defaultValue={current?.tier ?? 3}
                className="min-h-9 rounded-md border border-border bg-background px-2 text-sm text-foreground"
                aria-label={`${gm.label} tier number`}
              >
                {[1, 2, 3, 4, 5].map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
              <button
                type="submit"
                className="min-h-9 rounded-md bg-primary px-3 text-sm font-bold text-primary-foreground"
              >
                {current ? "Update" : "Set"}
              </button>
            </form>

            {current && (
              <>
                <span className="rounded border border-border bg-secondary px-2 py-1 font-mono text-xs text-foreground">
                  {tierLabel(current.tier, current.tierType)} · {current.points} pts
                </span>
                <form action={removeTier}>
                  <input type="hidden" name="playerId" value={player.id} />
                  <input type="hidden" name="gamemode" value={gm.id} />
                  <button
                    type="submit"
                    aria-label={`Remove ${gm.label} tier`}
                    className="flex min-h-9 items-center rounded-md border border-border px-2 text-muted-foreground hover:text-primary"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </form>
              </>
            )}
          </div>
        )
      })}
    </div>
  )
}

export function AdminPanel({ players }: { players: Player[] }) {
  return (
    <main className="mx-auto max-w-2xl px-4 py-6">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-bold font-display text-foreground">Smarmy Admin</h1>
        <form action={logoutAction}>
          <button
            type="submit"
            className="flex min-h-11 items-center gap-2 rounded-lg border border-border bg-card px-3 text-sm font-bold text-muted-foreground hover:text-foreground"
          >
            <LogOut className="h-4 w-4" />
            Log out
          </button>
        </form>
      </div>

      <form
        action={createPlayer}
        className="mb-6 rounded-xl border border-border bg-card p-4"
      >
        <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-muted-foreground">Add player</h2>
        <div className="flex flex-wrap items-center gap-2">
          <input
            name="username"
            placeholder="Minecraft username"
            required
            className="min-h-11 flex-1 rounded-lg border border-border bg-background px-3 text-base text-foreground outline-none focus:border-primary"
          />
          <input
            name="region"
            placeholder="Region (e.g. NA)"
            className="min-h-11 w-28 rounded-lg border border-border bg-background px-3 text-base text-foreground outline-none focus:border-primary"
          />
          <button
            type="submit"
            className="flex min-h-11 items-center gap-2 rounded-lg bg-primary px-4 font-bold text-primary-foreground"
          >
            <Plus className="h-4 w-4" />
            Add
          </button>
        </div>
      </form>

      <ul className="flex flex-col gap-3">
        {players.map((player) => (
          <li key={player.id} className="rounded-xl border border-border bg-card p-4">
            <div className="flex items-center gap-3">
              <img
                src={skinHead(player.username) || "/placeholder.svg"}
                alt={`${player.username} skin`}
                width={40}
                height={40}
                className="h-10 w-10 rounded-md border border-border"
                crossOrigin="anonymous"
              />
              <div className="min-w-0 flex-1">
                <p className="truncate font-bold font-display text-foreground">{player.username}</p>
                <p className="text-xs text-muted-foreground">
                  {player.region ?? "—"} · {player.totalPoints} total pts
                </p>
              </div>
              <form action={deletePlayer}>
                <input type="hidden" name="id" value={player.id} />
                <button
                  type="submit"
                  aria-label={`Delete ${player.username}`}
                  className="flex min-h-9 items-center rounded-md border border-border px-2 text-muted-foreground hover:text-primary"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </form>
            </div>

            <TierEditor player={player} />
          </li>
        ))}
      </ul>
    </main>
  )
}
