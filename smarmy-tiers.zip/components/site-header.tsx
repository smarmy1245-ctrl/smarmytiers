"use client"

import { useState } from "react"
import { Info, X } from "lucide-react"
import { POINTS } from "@/lib/tiers"

export function SiteHeader() {
  const [open, setOpen] = useState(false)

  return (
    <header className="sticky top-0 z-20 border-b border-border bg-background/85 backdrop-blur">
      <div className="mx-auto flex max-w-2xl items-center justify-between gap-3 px-4 py-3">
        <img
          src="/smarmy-logo.png"
          alt="Smarmy Tiers"
          className="h-10 w-auto"
        />
        <button
          onClick={() => setOpen(true)}
          className="flex min-h-11 items-center gap-2 rounded-lg border border-border bg-card px-3 text-sm font-bold text-muted-foreground transition-colors hover:text-foreground"
        >
          <Info className="h-4 w-4" aria-hidden="true" />
          Points
        </button>
      </div>

      {open && (
        <div
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 p-0 sm:items-center sm:p-4"
          role="dialog"
          aria-modal="true"
          aria-label="How ranking points are calculated"
          onClick={() => setOpen(false)}
        >
          <div
            className="w-full max-w-md rounded-t-2xl border border-border bg-popover p-5 sm:rounded-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-lg font-bold font-display text-foreground">How ranking points are calculated</h2>
              <button
                onClick={() => setOpen(false)}
                aria-label="Close"
                className="flex h-9 w-9 items-center justify-center rounded-md text-muted-foreground hover:text-foreground"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <ul className="flex flex-col gap-2">
              {Object.entries(POINTS).map(([tier, pts]) => (
                <li
                  key={tier}
                  className="flex items-center justify-between rounded-lg border border-border bg-card px-4 py-3"
                >
                  <span className="font-bold text-foreground">{`TIER ${tier}`}</span>
                  <span className="flex items-center gap-3 font-mono text-sm">
                    <span className="text-rose-400">
                      HT <span className="font-bold text-foreground">{pts.HT}</span>
                    </span>
                    <span className="text-emerald-400">
                      LT <span className="font-bold text-foreground">{pts.LT}</span>
                    </span>
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </header>
  )
}
